"use strict";
import {combineReducers} from "redux";

const mainReducer = combineReducers({

});

export {mainReducer}
